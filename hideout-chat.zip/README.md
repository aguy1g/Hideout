# Hideout: a guide

Hideout is a private chat and voice app for you and your friends. Messages, files, and voice are
end-to-end encrypted: the server stores only scrambled data it can't read.

---

## 1. Quick start

You need Node.js 18 or newer.

    cd secure-chat
    npm install
    npm start

Then open http://localhost:3000 in a browser.

To let friends join from anywhere, use the sharing command in section 2.

---

## 2. Sharing with friends

Install cloudflared once:

- Mac: `brew install cloudflared`
- Windows: `winget install Cloudflare.cloudflared`
- Linux: see Cloudflare's downloads page

Then run:

    npm run share

It starts the server and a free Cloudflare tunnel, then prints a link like
`https://something.trycloudflare.com/#code=abc123…`. Send that link to your friends.

- The link includes a random invite code, so new people can create accounts. People who already
  have an account just log in.
- The link changes every time you run `npm run share`.
- Press Ctrl+C to stop.
- To allow sign-ups without a code, run `npm run share -- --open`.

Voice and the microphone only work over HTTPS or on localhost. The tunnel provides HTTPS for you.

---

## 3. Your first time

**Create an account.** Click "Create account", choose a username (3–20 letters, numbers, `_` or `.`),
and set a password of at least 8 characters.

**Save your recovery key.** Right after sign-up you get a recovery key. It's shown once. Save it
in a password manager. It's the only way back into your account if you forget your password.
Hideout won't let you close the dialog until you tick "I've saved my recovery key".

**Log in later.** Use your username and password. If you forget the password, choose "Use a recovery
key instead". You'll be asked to set a new password straight away.

**Join a room.** Type a room name and a passphrase (at least 8 characters). The first person to join
a name creates the room and becomes its owner. Everyone else who types the same name and passphrase
gets in. The passphrase never leaves your device, so you must share it with friends separately.

Tick "Remember this room on this device" to skip the passphrase next time.

---

## 4. Using the room

The left side shows:

- **Room**: the room name, plus the Join voice button.
- **Channels**: #general and any channels you add with the "+" button.
- **People**: everyone online. Click someone to open a direct message.
- **Your card**: your name, with Edit (profile) and ⚙ (settings).

On a phone the same things appear as tabs along the top.

### Messages

- Hover over a message (or tap the ⋯ on a phone) to react, reply, edit, pin or delete.
- Your own messages can be edited. You can delete your own messages, and the room owner can delete anyone's.
- Format with `**bold**`, `*italic*`, `~~strike~~`, `` `code` `` and triple backticks for code blocks.
- Type `@` and a name to mention someone. Mentioned messages are highlighted. `@everyone` works in channels.
- 📎 attaches a file or image (8 MB max). You can also paste or drag one in. Photos are resized
  and stripped of location data before they're sent.
- 📊 makes a poll with 2 to 6 options.
- 😊 opens the emoji picker.
- **Search** and **📌 Pins** appear above the message list.
- "NEW" marks where you left off.

### Channels

Click the "+" next to Channels to make one. Channels are shared by everyone in the room.

### Direct messages

Click someone's name in the People list to open a private chat. Only the two of you can read it.
Use **Call** at the top to start a private voice call (with screen sharing).

### Voice

Click **Join voice**. Everyone who has joined voice can hear each other. Green rings show who is speaking.
Use **Mute** to stop your microphone. **Share screen** shows your screen to everyone in voice.
Voice works best with 2–5 people.

---

## 4b. Daily-use shortcuts and tools

| Keys | Does |
|---|---|
| Ctrl/Cmd + K | Quick switcher: type part of a channel or person's name, Enter to jump |
| Alt + Up / Down | Previous / next conversation |
| Up (empty message box) | Edit your last message |
| Ctrl/Cmd + Shift + F | Search this conversation |
| Shift + Esc | Mark everything read |
| Ctrl/Cmd + / | Show this list in the app |

- **Drafts:** unsent text is kept per conversation on this device and comes back when you return.
- **Threads:** "Thread" in a message's actions opens a side conversation. Replies stay out of the main log and show as "💬 N replies".
- **Saved messages:** "Save" in the actions bookmarks a message privately on this device. Sidebar > Saved messages lists them with Jump.
- **Undo delete:** deleting shows "Undo" for 6 seconds. The server is only told when the time is up.

## 4c. Desktop apps (Windows and Mac)

The `desktop/` folder is an Electron app that wraps Hideout. It adds a system tray (close-to-tray), start on login, unread badge, a screen/window picker for screen share, **push-to-talk that works while another app (a game) is focused**, and an optional "Playing X" status from running games. Turn these on in Account > Desktop app.

First launch asks for your server address (the link your host shares). Hideout > Change server... resets it.

**Getting the installers**
1. Easiest: push the project to GitHub and run the "Build desktop apps" workflow (Actions tab). It builds on real Mac and Windows machines and uploads a `.dmg`/`.zip` for Mac and an installer `.exe`/`.zip` for Windows.
2. Or build on the machine itself: `cd desktop && npm install`, then `npm run dist:win` on Windows or `npm run dist:mac` on a Mac. Output goes in `desktop/dist/`.
3. To just try it: `cd desktop && npm install && npm start`.

**Honest notes**
- The apps are **not code-signed**. Windows SmartScreen shows "Windows protected your PC" (More info > Run anyway). On Mac, right-click the app > Open the first time (or System Settings > Privacy & Security > Open Anyway). Signing needs paid developer accounts.
- Mac global push-to-talk needs permission: System Settings > Privacy & Security > Input Monitoring (and Accessibility) > enable Hideout, then restart it. Microphone permission is asked as usual.
- Game detection is a simple list of well-known game process names (`desktop/games.js`); add your own.
- Tested here: the app starts on Linux, loads the server, and the bridge/push-to-talk hook load. Windows and Mac zips were packaged here but **not run** on those systems.

## 5. Profiles, status and settings

- **Edit profile**: display name, a short bio, avatar, banner and colour. Only your friends see it.
- **Status**: from the ⚙ settings, choose Online, Away or Do not disturb, and add a short line
  such as "playing Minecraft". Do not disturb silences sounds and desktop notifications.
- **Blocking**: click someone's profile card, then Block. Their messages are hidden for you and
  their voice is muted. They aren't told. Unblock under Settings → Blocked people.
- **Nicknames and voice volume**: set on someone's profile card. Only you see them.

### Account settings (⚙)

- **Appearance**: theme, accent colour, text size, spacing, 24-hour time, and reduced motion.
  These are saved on this device only.
- **Notifications**: sound on or off, volume, desktop notifications, and whether channels notify
  on every message or only when you're mentioned.
- **Voice**: microphone choice, push-to-talk and its key.
- **Username and password**: both ask for your current password.
- **Recovery key**: make a new one (this replaces the old one).
- **Devices**: log out every other phone or computer signed in as you.
- **Delete account**: removes your account, your messages and your DMs. Can't be undone.

---

## 6. Room settings (owner only)

Click **Room settings** in the left panel. The owner can set:

- **Slow mode**: how many seconds people must wait between channel messages (5 seconds to 5 minutes).
- **Auto-delete**: remove messages after 1, 7, 30 or 90 days, or never.
- **Most people at once**: a limit from 2 to 12.
- **Files and images**: on or off.
- **Anyone can create channels**: on or off.
- **Closed to new people**: when on, only people who already joined can come back.

The owner can also kick or ban someone from their profile card, unban people, and delete channels.
Everyone can read the room settings, but only the owner can change them.

---

## 7. Hosting it yourself

### On your own computer

Your computer must stay on for others to connect. `npm run share` is the easiest way.

### On a server (VPS or home server)

1. Copy the project, run `npm install`, and set environment variables (see section 8).
2. Put the app behind HTTPS. Caddy is the simplest option:

       yourdomain.com {
           reverse_proxy localhost:3000
       }

   Caddy gets the certificate automatically.
3. Set `TRUST_PROXY=1` so the server sees real visitor addresses for rate limits.
4. Keep it running with a process manager such as `pm2 start server.js --name hideout` or a systemd service.
5. Schedule backups (section 9).

---

## 8. Settings the server reads (environment variables)

| Variable | What it does |
|---|---|
| `PORT` | Port to listen on. Default 3000. |
| `DATA_DIR` | Where accounts, rooms and files are saved. Default `./data`. |
| `SIGNUP_CODE` | If set, people need this code to create an account. |
| `MAX_ACCOUNTS` | Maximum number of accounts. Default 200. |
| `MAX_ROOMS` | Maximum number of rooms. Default 100. |
| `ROOM_TTL_DAYS` | Rooms nobody has used for this many days are deleted. Default 180. |
| `ADMIN_USERS` | Comma-separated usernames that get the Admin page, e.g. `you,friend`. |
| `TRUST_PROXY` | Set to `1` when behind a proxy or tunnel. |
| `TLS_KEY` / `TLS_CERT` | Paths to certificate files, to serve HTTPS directly. |
| `CF_TURN_KEY_ID` / `CF_TURN_API_TOKEN` | Cloudflare Realtime TURN, a voice relay for strict networks. |
| `TURN_URLS` with `TURN_SECRET` | Your own TURN server (for example coturn). |
| `TURN_URLS` with `TURN_USERNAME` / `TURN_CREDENTIAL` | A TURN server with fixed login details. |

Example:

    SIGNUP_CODE=pizza-night ADMIN_USERS=you npm start

---

## 9. Backups

    npm run backup

This saves everything in the data folder to `hideout-backup-DATE.tgz`.

To restore, stop the server, then run:

    npm run backup -- --restore hideout-backup-DATE.tgz

Keep backups private. They contain everyone's accounts and encrypted history.

---

## 10. Admin page

If your username is in `ADMIN_USERS`, Account settings has an "Open admin page" button. It lists
accounts and rooms (member counts, file space used) and lets you remove them. Admins can't read
messages, but they can see account names, room names and activity.

---

## 11. What the server can and can't see

**It can't see:** room passphrases, message text, reactions, poll votes, channel names, files,
profiles, or the content of voice and screen sharing.

**It can see:** usernames, room names, who is in which room, who messages whom and when, file sizes,
and how much data each room stores.

**Other things to know:**

- Passwords and recovery keys never leave your browser. The server stores a scrambled form.
- If you lose your password *and* your recovery key, your account can't be recovered.
- If you forget a room's passphrase, you can't join that room.
- Blocking, mutes, nicknames, read markers and appearance settings live on each device only.
- DMs don't have forward secrecy, so they can be read later by someone who gets your key. This is the trade-off for keeping DM history after reloads.
- Message history keeps the most recent 500 messages per channel or DM.

---

## 12. Troubleshooting

| Problem | What to check |
|---|---|
| "This page needs HTTPS" | Open the link over `https://` or use `localhost`. |
| Can't hear anyone | Check the microphone permission, then leave and rejoin voice. |
| Voice won't connect on some networks | Strict firewalls and mobile networks can block direct connections. Set up a TURN relay (section 8). |
| "Too many attempts" | Wait 10–15 minutes. Failed logins and wrong passphrases are rate limited. |
| "Room is full" | The room has reached its member limit. Ask the owner to raise it. |
| "Your session expired" | Log in again. Sessions last 30 days, or until you change your password. |
| Share link stopped working | The tunnel link changes each time you run `npm run share`. Send the new one. |
| Friends see old messages but not new ones after a restart | Make sure the server stopped cleanly (Ctrl+C) and that `DATA_DIR` is the same folder. |

---

## 13. Files in this project

- `server.js`: the server (accounts, rooms, relay, admin).
- `public/`: the web app (`index.html`, `app.js`, `crypto.js`).
- `scripts/share.js`: `npm run share`.
- `scripts/backup.js`: `npm run backup`.
- `README.md` (inside `secure-chat/`): a short technical summary.
- `data/`: created on first run. Accounts, rooms and files live here.
